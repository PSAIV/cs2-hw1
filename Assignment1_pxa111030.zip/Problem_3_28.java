import java.util.Scanner;
//3.28
public class Problem_3_28 {
	
	public static void main(String[] args){
		//Open the scanner
		Scanner s = new Scanner(System.in);
		//Prompt user for first rectangle dimensions
		System.out.println("Enter r1's center x-, y-coordinates, width, and height: ");
		//Store first rectangle dimensions
		double r1x = s.nextDouble();
		double r1y = s.nextDouble();
		double r1width = s.nextDouble();
		double r1height = s.nextDouble();
		
		//Prompt user for second rectangle dimensions
		System.out.println("Enter r2's center x-, y-coordinates, width, and height: ");
		double r2x = s.nextDouble();
		double r2y = s.nextDouble();
		double r2width = s.nextDouble();
		double r2height = s.nextDouble();
		s.close();
		
		if(r1x + (r1width / 2) > r2x + (r2width / 2) && r1x - (r1width / 2) < r2x - (r2width / 2)  &&
			r1y + (r1height / 2) > r2y + (r2height / 2) && r1y - (r1height / 2) < r2y - (r2height / 2)){
			System.out.println("The second rectangle is completely inside the first.");
		}
		else if(r1x + (r1width / 2) > r2x + (r2width / 2) && r1x - (r1width / 2) < r2x - (r2width / 2)  ||
			r1y + (r1height / 2) > r2y + (r2height / 2) && r1y - (r1height / 2) < r2y - (r2height / 2)){
			System.out.println("The second rectangle is overlapped by the first.");
		}
		else
			System.out.println("The two rectangles do not overlap");
	}

}
