import java.util.Scanner;
 
//3.15
public class Problem_3_15 {
    public static void main(String [] args){
 
    //Generate random number with 3 digits
    int randomNumber = 100 + (int)(Math.random() * ((999 - 100)+1));
    int award;
    //Start scanner
    Scanner s = new Scanner (System.in);
    //Prompt user to enter three digits
    System.out.println(" Enter the three digit integer");
    int userNumber = s.nextInt();
    s.close();
     
    int u1 = userNumber /100;
    int remainU = userNumber % 100;
     
    int u2 = remainU /10;
    int u3= remainU % 10;
 
 
    //Get  3 digits from lottery
     
    int d1 = randomNumber /100;
    int remainN = randomNumber % 100;
     
    int d2 = remainN /10;
    int d3= remainN % 10;
 
    System.out.println(" The lottery numbers are " + d1 + "" + d2 + "" + d3);
    //Check guesses
    //Check for perfect match
    if (userNumber == randomNumber ){
        award = 10000;
        System.out.println("Perfect match!");
 
    //Check for all digits matching
     
    }else if (((u1 == d1) || (u1 == d2) || (u1 == d3)) && 
            ((u2 == d1) || (u2 == d2) || (u2 == d3)) &&
            ((u3 == d1) || (u3 == d2) || (u3 == d3))){  
        award = 3000;
        System.out.println("All numbers correct!");
         
    //Check for any match
    }else if (((u1 == d1) || (u1 == d2) || (u1 == d3)) || 
            ((u2 == d1) || (u2 == d2) || (u2 == d3)) ||
            ((u3 == d1) || (u3 == d2) || (u3 == d3))){
        award = 1000;
        System.out.println("At least one match!");
    //If no matches are found
    }else {
        award = 0;
        System.out.println("No match.");
    }
    //Display award
    System.out.println("Your winnings are: $" + award);
    System.out.println("Thanks for playing!");
  }
}